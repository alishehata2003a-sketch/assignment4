const express = require('express');
const mysql = require('mysql2/promise');

const app = express();
app.use(express.json());

// 1. Database Connection Pool Setup
const pool = mysql.createPool({
    host: 'localhost',
    user: 'root',
    password: '',
    database: 'store_db',
    waitForConnections: true,
    connectionLimit: 10,
    queueLimit: 0
});

// Initialize Database and Tables
async function initDB() {
    const connection = await mysql.createConnection({ host: 'localhost', user: 'root', password: '' });
    await connection.query(`CREATE DATABASE IF NOT EXISTS store_db;`);
    await connection.end();

    const db = await pool;
    await db.query(`
        CREATE TABLE IF NOT EXISTS Suppliers (
            SupplierID INT AUTO_INCREMENT PRIMARY KEY,
            SupplierName TEXT NOT NULL,
            ContactNumber TEXT
        );
    `);
    await db.query(`
        CREATE TABLE IF NOT EXISTS Products (
            ProductID INT AUTO_INCREMENT PRIMARY KEY,
            ProductName VARCHAR(255),
            Price DECIMAL(10,2),
            StockQuantity INT,
            SupplierID INT,
            FOREIGN KEY (SupplierID) REFERENCES Suppliers(SupplierID)
        );
    `);
    await db.query(`
        CREATE TABLE IF NOT EXISTS Sales (
            SaleID INT AUTO_INCREMENT PRIMARY KEY,
            ProductID INT,
            QuantitySold INT,
            SaleDate DATE,
            FOREIGN KEY (ProductID) REFERENCES Products(ProductID)
        );
    `);
    console.log("Database and tables initialized successfully.");
}
initDB();

// --- 2. Products CRUD ---
app.post('/products', async (req, res) => {
    try {
        const { ProductName, Price, StockQuantity, SupplierID } = req.body;
        const [result] = await pool.query('INSERT INTO Products (ProductName, Price, StockQuantity, SupplierID) VALUES (?, ?, ?, ?)', [ProductName, Price, StockQuantity, SupplierID]);
        res.json({ message: "Product created successfully", ProductID: result.insertId });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/products', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM Products');
        res.json(rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/products/:id', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM Products WHERE ProductID = ?', [req.params.id]);
        if (rows.length === 0) return res.status(404).json({ message: "Product not found" });
        res.json(rows[0]);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.put('/products/:id', async (req, res) => {
    try {
        const { ProductName, Price, StockQuantity, SupplierID } = req.body;
        await pool.query('UPDATE Products SET ProductName = ?, Price = ?, StockQuantity = ?, SupplierID = ? WHERE ProductID = ?', [ProductName, Price, StockQuantity, SupplierID, req.params.id]);
        res.json({ message: "Product updated successfully" });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/products/:id', async (req, res) => {
    try {
        await pool.query('DELETE FROM Products WHERE ProductID = ?', [req.params.id]);
        res.json({ message: "Product deleted successfully" });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// --- 3. Suppliers CRUD ---
app.post('/suppliers', async (req, res) => {
    try {
        const { SupplierName, ContactNumber } = req.body;
        const [result] = await pool.query('INSERT INTO Suppliers (SupplierName, ContactNumber) VALUES (?, ?)', [SupplierName, ContactNumber]);
        res.json({ message: "Supplier created successfully", SupplierID: result.insertId });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/suppliers', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM Suppliers');
        res.json(rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.put('/suppliers/:id', async (req, res) => {
    try {
        const { SupplierName, ContactNumber } = req.body;
        await pool.query('UPDATE Suppliers SET SupplierName = ?, ContactNumber = ? WHERE SupplierID = ?', [SupplierName, ContactNumber, req.params.id]);
        res.json({ message: "Supplier updated successfully" });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.delete('/suppliers/:id', async (req, res) => {
    try {
        await pool.query('DELETE FROM Suppliers WHERE SupplierID = ?', [req.params.id]);
        res.json({ message: "Supplier deleted successfully" });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// --- 4. Sales Management ---
app.post('/sales', async (req, res) => {
    try {
        const { ProductID, QuantitySold, SaleDate } = req.body;
        const [result] = await pool.query('INSERT INTO Sales (ProductID, QuantitySold, SaleDate) VALUES (?, ?, ?)', [ProductID, QuantitySold, SaleDate]);
        res.json({ message: "Sale recorded successfully", SaleID: result.insertId });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/sales', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM Sales');
        res.json(rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

app.get('/sales/product/:productId', async (req, res) => {
    try {
        const [rows] = await pool.query('SELECT * FROM Sales WHERE ProductID = ?', [req.params.productId]);
        res.json(rows);
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// --- 5. Database Modifications ---
app.post('/db/modify-schema', async (req, res) => {
    try {
        await pool.query('ALTER TABLE Products ADD COLUMN Category VARCHAR(255);');
        await pool.query('ALTER TABLE Products DROP COLUMN Category;');
        await pool.query('ALTER TABLE Suppliers MODIFY COLUMN ContactNumber VARCHAR(15);');
        await pool.query('ALTER TABLE Products MODIFY COLUMN ProductName VARCHAR(255) NOT NULL;');
        res.json({ message: "Schema modifications executed successfully" });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// --- 6. Seed Initial Data ---
app.post('/db/seed', async (req, res) => {
    try {
        const [supResult] = await pool.query('INSERT INTO Suppliers (SupplierName, ContactNumber) VALUES (?, ?)', ['FreshFoods', '01001234567']);
        const supplierId = supResult.insertId;

        await pool.query('INSERT INTO Products (ProductName, Price, StockQuantity, SupplierID) VALUES ?', [
            [['Milk', 15.00, 50, supplierId], ['Bread', 10.00, 30, supplierId], ['Eggs', 20.00, 40, supplierId]]
        ]);

        const [milkRows] = await pool.query('SELECT ProductID FROM Products WHERE ProductName = ?', ['Milk']);
        const milkId = milkRows[0].ProductID;

        await pool.query('INSERT INTO Sales (ProductID, QuantitySold, SaleDate) VALUES (?, ?, ?)', [milkId, 2, '2025-05-20']);

        res.json({ message: "Initial data seeded successfully" });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

// --- 7 & 8. Update/Delete Specific Products ---
app.put('/products/update-bread', async (req, res) => {
    await pool.query('UPDATE Products SET Price = 25.00 WHERE ProductName = ?', ['Bread']);
    res.json({ message: "Bread price updated to 25.00" });
});

app.delete('/products/delete-eggs', async (req, res) => {
    await pool.query('DELETE FROM Products WHERE ProductName = ?', ['Eggs']);
    res.json({ message: "Eggs deleted successfully" });
});

// --- 9 to 13. Reporting Endpoints ---
app.get('/reports/total-sold', async (req, res) => {
    const [rows] = await pool.query('SELECT p.ProductName, SUM(s.QuantitySold) as TotalQuantitySold FROM Products p LEFT JOIN Sales s ON p.ProductID = s.ProductID GROUP BY p.ProductID');
    res.json(rows);
});

app.get('/reports/highest-stock', async (req, res) => {
    const [rows] = await pool.query('SELECT * FROM Products ORDER BY StockQuantity DESC LIMIT 1');
    res.json(rows[0]);
});

app.get('/reports/suppliers-f', async (req, res) => {
    const [rows] = await pool.query("SELECT * FROM Suppliers WHERE SupplierName LIKE 'F%'");
    res.json(rows);
});

app.get('/reports/never-sold', async (req, res) => {
    const [rows] = await pool.query('SELECT * FROM Products WHERE ProductID NOT IN (SELECT DISTINCT ProductID FROM Sales)');
    res.json(rows);
});

app.get('/reports/all-sales', async (req, res) => {
    const [rows] = await pool.query('SELECT p.ProductName, s.QuantitySold, s.SaleDate FROM Sales s JOIN Products p ON s.ProductID = p.ProductID');
    res.json(rows);
});

// --- 14, 15, 16. Database Users & Permissions ---
app.post('/db/permissions', async (req, res) => {
    try {
        await pool.query("CREATE USER IF NOT EXISTS 'store_manager'@'localhost' IDENTIFIED BY 'password123';");
        await pool.query("GRANT SELECT, INSERT, UPDATE ON store_db.* TO 'store_manager'@'localhost';");
        await pool.query("REVOKE UPDATE ON store_db.* FROM 'store_manager'@'localhost';");
        await pool.query("GRANT DELETE ON store_db.Sales TO 'store_manager'@'localhost';");
        res.json({ message: "Permissions configured successfully" });
    } catch (err) { res.status(500).json({ error: err.message }); }
});

const PORT = 3000;
app.listen(PORT, () => { console.log(`Server running on port ${PORT}`); });