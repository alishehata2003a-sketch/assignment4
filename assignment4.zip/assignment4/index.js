/**
 * Assignment 4 - Part 1 & Part 2 Solutions
 * 
 * Part 1: ERD Diagram Entities & Relationships Summary:
 * - Musician: ID, name, address (street, city), phone number. Plays many Instruments and performs many Songs.
 * - Instrument: unique name, musical key (e.g., C, B-flat). Played by many Musicians.
 * - Album: unique title, copyright date, album identifier. Has many Songs, exactly one Producer, and exactly one Producer produces many Albums.
 * - Song: unique title, author. Performed by one or more Musicians, appears on a single Album.
 * - Producer: Acts as a producer for an album, produces several albums.
 * 
 * Part 2: Schema Design (Mapping from ERD to Relational Tables):
 * 1. Users Table: id (PK), firstName, lastName, username, email, password, phone, role, isDeleted
 * 2. Products Table: id (PK), name, stock, price
 * 3. Own Table (Relation): userID (FK referencing Users), productID (FK referencing Products)
 */
console.log("Part 1 and Part 2 documentation loaded.");